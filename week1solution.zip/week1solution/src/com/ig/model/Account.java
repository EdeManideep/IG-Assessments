package com.ig.model;

import com.ig.exception.InsufficientFundsException;
import com.ig.exception.InvalidAmountException;
import com.ig.exception.LowBalanceException;

public class Account {
    private Integer accNumber;
    private String custNameString;
    private AccountType type;
    private Float balance;

    public enum AccountType {
        SAVINGS, CURRENT
    }

    public Account(Integer accNumber, String custName, AccountType type, Float balance) throws InvalidAmountException, LowBalanceException {
        if (balance < 0) {
            throw new InvalidAmountException("Initial balance cannot be negative");
        }
        if ((type == AccountType.SAVINGS && balance < 1000) || (type == AccountType.CURRENT && balance < 5000)) {
            throw new LowBalanceException("Initial balance is too low");
        }
        this.accNumber = accNumber;
        this.custNameString = custName;
        this.type = type;
        this.balance = balance;
    }

    public Integer getAccNumber() {
        return accNumber;
    }

    public Float getBalance() {
        return balance;
    }

    public void deposit(float amt) throws InvalidAmountException {
        if (amt <= 0) {
            throw new InvalidAmountException("Deposit amount must be positive");
        }
        balance += amt;
    }

    public void withdraw(float amt) throws InvalidAmountException, InsufficientFundsException {
        if (amt < 500) {
            throw new InvalidAmountException("Minimum withdrawal amount is 500");
        }
        float minBalance = (type == AccountType.SAVINGS) ? 1000 : 5000;
        if (balance - amt < minBalance) {
            throw new InsufficientFundsException("Insufficient funds to maintain minimum balance");
        }
        balance -= amt;
    }
}