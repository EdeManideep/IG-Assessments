package com.ig.service;

import com.ig.model.Account;
import com.ig.exception.*;
import java.util.ArrayList;
import java.util.List;

public class AccountService {
    private List<Account> accountList = new ArrayList<>();

    public void addAccount(Account account) {
        accountList.add(account);
    }

    public boolean isValidAccount(int accNumber) throws AccountNotFoundException {
        return accountList.stream().anyMatch(acc -> acc.getAccNumber().equals(accNumber));
    }

    public Account getAccount(int accNumber) throws AccountNotFoundException {
        return accountList.stream()
                .filter(acc -> acc.getAccNumber().equals(accNumber))
                .findFirst()
                .orElseThrow(() -> new AccountNotFoundException("Account not found"));
    }
}