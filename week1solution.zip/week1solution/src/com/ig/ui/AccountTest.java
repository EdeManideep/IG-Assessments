package com.ig.ui;

import com.ig.model.Account;
import com.ig.service.AccountService;
import com.ig.exception.*;

public class AccountTest {
    public static void main(String[] args) {
        AccountService service = new AccountService();

        try {
            service.addAccount(new Account(101, "Alice", Account.AccountType.SAVINGS, 5000f));
            service.addAccount(new Account(102, "Bob", Account.AccountType.CURRENT, 10000f));
            service.addAccount(new Account(103, "Charlie", Account.AccountType.SAVINGS, 3000f));
            service.addAccount(new Account(104, "David", Account.AccountType.CURRENT, 7000f));
            service.addAccount(new Account(105, "Eve", Account.AccountType.SAVINGS, 2000f));

            System.out.println("Account 102 exists: " + service.isValidAccount(102));
            Account acc = service.getAccount(101);
            acc.deposit(2000);
            System.out.println("New balance after deposit: " + acc.getBalance());
            acc.withdraw(1000);
            System.out.println("New balance after withdrawal: " + acc.getBalance());

        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
}
