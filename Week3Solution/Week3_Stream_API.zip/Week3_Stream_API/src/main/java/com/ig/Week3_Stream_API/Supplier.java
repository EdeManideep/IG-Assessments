package com.ig.Week3_Stream_API;

class Supplier {
    Integer id;
    String sname;

    public Supplier(Integer id, String sname) {
        this.id = id;
        this.sname = sname;
    }
}