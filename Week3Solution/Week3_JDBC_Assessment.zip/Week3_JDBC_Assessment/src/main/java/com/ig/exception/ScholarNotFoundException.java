package com.ig.exception;

public class ScholarNotFoundException extends Exception {
    public ScholarNotFoundException(String message) {
        super(message);
    }
}
